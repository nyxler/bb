from datetime import timezone

import discord
from discord.ext import commands
import config


class JoinLeaveView(discord.ui.View):
    """Moderator actions attached to join/leave log messages."""

    def __init__(self, bot: commands.Bot, member_id: int, guild_id: int):
        super().__init__(timeout=None)
        self.bot = bot
        self.member_id = member_id
        self.guild_id = guild_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message("This action can only be used in a server.", ephemeral=True)
            return False

        user = interaction.user
        configured_owners = set(getattr(config, "OWNER_IDS", []))
        is_authorized = (
            user.id == guild.owner_id
            or user.id in configured_owners
            or (isinstance(user, discord.Member) and user.guild_permissions.administrator)
            or (isinstance(user, discord.Member) and user.guild_permissions.ban_members)
        )
        if not is_authorized:
            await interaction.response.send_message("You do not have permission to use this action.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Mark Reviewed", style=discord.ButtonStyle.success, custom_id="durex_joinlog_review")
    async def review_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            f"Member ID `{self.member_id}` was marked as reviewed by {interaction.user.mention}.",
            ephemeral=True,
        )

    @discord.ui.button(label="Ban Member", style=discord.ButtonStyle.danger, custom_id="durex_joinlog_ban")
    async def ban_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message("This action can only be used in a server.", ephemeral=True)
            return

        member = guild.get_member(self.member_id)
        if member is None:
            try:
                user = await self.bot.fetch_user(self.member_id)
            except (discord.NotFound, discord.HTTPException):
                await interaction.response.send_message("Could not find that user.", ephemeral=True)
                return
        else:
            user = member

        try:
            await guild.ban(user, reason=f"Banned from join/leave log by {interaction.user} ({interaction.user.id})")
            await interaction.response.send_message(f"Banned **{user}**.", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message(
                "I cannot ban this user. Check my Ban Members permission and role hierarchy.", ephemeral=True
            )
        except discord.HTTPException:
            await interaction.response.send_message("Discord rejected the ban request. Please try again.", ephemeral=True)


class LoggingCog(commands.Cog):
    """Incident, alert, and member join/leave logging for Durex Security."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _get_text_channel(self, guild: discord.Guild, channel_id: int):
        channel = guild.get_channel(int(channel_id or 0))
        return channel if isinstance(channel, (discord.TextChannel, discord.Thread)) else None

    async def log_incident(self, guild: discord.Guild, description: str, user: discord.abc.User | None = None):
        channel = self._get_text_channel(guild, getattr(config, "LOG_CHANNEL_ID", 0))
        embed = discord.Embed(
            title="Security Incident",
            description=description[:3900],
            color=discord.Color.orange(),
            timestamp=discord.utils.utcnow(),
        )
        if user:
            embed.set_author(name=str(user), icon_url=user.display_avatar.url)
        await self._send_or_console(channel, embed, guild.id)

    async def alert(self, guild: discord.Guild, text: str):
        channel = self._get_text_channel(guild, getattr(config, "LOG_CHANNEL_ID", 0))
        embed = discord.Embed(
            title="Security Alert",
            description=text[:3900],
            color=discord.Color.red(),
            timestamp=discord.utils.utcnow(),
        )
        await self._send_or_console(channel, embed, guild.id)

    async def _send_or_console(self, channel, embed: discord.Embed, guild_id: int):
        if channel is None:
            print(f"[LOG][{guild_id}] {embed.title}: {embed.description}")
            return
        try:
            await channel.send(embed=embed)
        except (discord.Forbidden, discord.HTTPException) as exc:
            print(f"[LOG][{guild_id}] Could not send log ({type(exc).__name__}): {embed.title}: {embed.description}")

    async def log_join_leave(self, guild: discord.Guild, user: discord.abc.User, event_type: str):
        channel_id = getattr(config, "JOIN_LEAVE_LOG_CHANNEL_ID", 0) or getattr(config, "LOG_CHANNEL_ID", 0)
        channel = self._get_text_channel(guild, channel_id)
        is_join = event_type == "join"
        embed = discord.Embed(
            title="Member Joined" if is_join else "Member Left",
            color=discord.Color.green() if is_join else discord.Color.red(),
            timestamp=discord.utils.utcnow(),
        )
        embed.add_field(name="Username", value=str(user), inline=False)
        embed.add_field(name="User ID", value=str(user.id), inline=False)
        created_at = user.created_at.astimezone(timezone.utc).strftime("%d %b %Y, %H:%M:%S UTC")
        embed.add_field(name="Account Created", value=created_at, inline=False)
        embed.add_field(name="Bot Account", value="Yes" if user.bot else "No", inline=False)
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text=f"Durex Security • Guild ID: {guild.id}")

        view = JoinLeaveView(self.bot, user.id, guild.id) if is_join else None
        await self._send_or_console(channel, embed, guild.id) if view is None else await self._send_with_view(channel, embed, view, guild.id)

    async def _send_with_view(self, channel, embed, view, guild_id: int):
        if channel is None:
            print(f"[LOG][{guild_id}] {embed.title}: {embed.to_dict()}")
            return
        try:
            await channel.send(embed=embed, view=view)
        except (discord.Forbidden, discord.HTTPException) as exc:
            print(f"[LOG][{guild_id}] Could not send member log ({type(exc).__name__}).")

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        await self.log_join_leave(member.guild, member, "join")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        await self.log_join_leave(member.guild, member, "leave")


async def setup(bot: commands.Bot):
    await bot.add_cog(LoggingCog(bot))
