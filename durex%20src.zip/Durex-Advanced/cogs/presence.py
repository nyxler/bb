import discord
from discord.ext import commands, tasks

class Presence(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._presence.start()

    def cog_unload(self):
        self._presence.cancel()

    @tasks.loop(minutes=1)
    async def _presence(self):
        security = self.bot.get_cog("Security")
        count = getattr(security, "incident_count", 0) if security else 0
        await self.bot.change_presence(activity=discord.Activity(
            type=discord.ActivityType.watching,
            name=f"Incidents: {count}"
        ))

    @_presence.before_loop
    async def before_presence(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    await bot.add_cog(Presence(bot))
