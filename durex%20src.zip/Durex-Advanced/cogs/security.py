import asyncio
import json
import time
from collections import defaultdict, deque
from pathlib import Path

import discord
from discord.ext import commands
import config
from utils.security import find_audit_actor, strip_manageable_roles
from utils.store import load_state, save_state, list_extraowners

PROTECTED_ROLE_NAME = "Power of Durex"
MODULES = {
    "roles": "AntiRole",
    "channels": "AntiChannel",
    "webhooks": "AntiWebhook",
    "antibot": "AntiBot Add",
    "kicks": "AntiKick",
    "bans": "AntiBan",
    "guildUpdate": "AntiGuild Update",
    "emojis": "AntiEmoji",
    "prune": "AntiPrune",
}

class Security(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        try:
            raw = json.loads(load_state("security_state") or "{}")
        except (TypeError, json.JSONDecodeError):
            raw = {}
        self.enabled = {int(k): bool(v) for k, v in raw.get("enabled", {}).items()}
        self.betrayal = {int(k): bool(v) for k, v in raw.get("betrayal", {}).items()}
        self.whitelist = {int(k): {int(x) for x in v} for k, v in raw.get("whitelist", {}).items()}
        self.protected_ids = {int(k): int(v) for k, v in raw.get("protected_ids", {}).items()}
        self.snapshots = {int(k): v for k, v in raw.get("snapshots", {}).items()}
        self.modules = {int(k): {str(m): bool(v) for m, v in values.items()} for k, values in raw.get("modules", {}).items()}
        for gid, enabled in self.enabled.items():
            self.modules.setdefault(gid, {m: enabled for m in MODULES})
        self.ban_events = defaultdict(deque)
        self.kick_events = defaultdict(deque)
        self.incident_count = 0

    def save(self):
        payload = {
            "enabled": {str(k): v for k, v in self.enabled.items()},
            "betrayal": {str(k): v for k, v in self.betrayal.items()},
            "whitelist": {str(k): sorted(v) for k, v in self.whitelist.items()},
            "protected_ids": {str(k): v for k, v in self.protected_ids.items()},
            "snapshots": {str(k): v for k, v in self.snapshots.items()},
            "modules": {str(k): v for k, v in self.modules.items()},
        }
        save_state("security_state", json.dumps(payload, separators=(",", ":")))

    def active(self, guild_id, module):
        return self.betrayal.get(guild_id, False) or self.modules.get(guild_id, {}).get(module, False)

    def is_trusted(self, guild, user_id):
        if self.betrayal.get(guild.id, False):
            return user_id == guild.owner_id
        return (user_id == guild.owner_id
                or user_id in set(getattr(config, "OWNER_IDS", []))
                or user_id in set(list_extraowners(guild.id))
                or user_id in self.whitelist.get(guild.id, set()))

    async def log(self, guild, title, description, color=discord.Color.orange()):
        self.incident_count += 1
        channel_id = int(getattr(config, "LOG_CHANNEL_ID", 0) or 0)
        channel = guild.get_channel(channel_id) if channel_id else None
        embed = discord.Embed(title=title, description=description[:3900], color=color, timestamp=discord.utils.utcnow())
        embed.set_footer(text="Durex Security | Security Events")
        try:
            if channel and hasattr(channel, "send"):
                await channel.send(embed=embed)
            else:
                print(f"[SECURITY][{guild.id}] {title}: {description}")
        except (discord.Forbidden, discord.HTTPException):
            print(f"[SECURITY][{guild.id}] {title}: {description}")

    async def owner_only(self, ctx):
        if ctx.author.id != ctx.guild.owner_id:
            e = discord.Embed(title="Permission denied", description="Only this Discord server's owner can change security settings.", color=discord.Color.red())
            await ctx.reply(embed=e, mention_author=False)
            return False
        return True

    async def ensure_protected_role(self, guild):
        role = guild.get_role(self.protected_ids.get(guild.id, 0))
        if role is None:
            me = guild.me
            if me is None or not me.guild_permissions.manage_roles:
                raise commands.CommandError("Bot needs Manage Roles permission to create Power of Durex.")
            role = await guild.create_role(name=PROTECTED_ROLE_NAME, permissions=discord.Permissions.none(), reason="Durex Security protected-role setup")
            self.protected_ids[guild.id] = role.id
            self.snapshots[guild.id] = {"name": role.name, "permissions": role.permissions.value, "colour": role.colour.value, "hoist": role.hoist, "mentionable": role.mentionable}
            self.save()
        return role

    async def respond_to_actor(self, guild, actor_id, reason):
        actor = guild.get_member(actor_id)
        if actor is None:
            result = "Actor is not present; no role changes attempted."
        elif self.is_trusted(guild, actor_id):
            result = "Actor is trusted under the current mode; no role changes attempted."
        else:
            _, result = await strip_manageable_roles(actor, reason)
        await self.log(guild, "Security response", f"Actor ID: `{actor_id}`\nTrigger: {reason}\nResult: {result}", discord.Color.red())

    def module_embed(self, guild):
        e = discord.Embed(title="Durex Security | AntiNuke Status", color=discord.Color.blurple(), timestamp=discord.utils.utcnow())
        values = self.modules.get(guild.id, {m: False for m in MODULES})
        e.description = f"Anti-Betrayal: **{'ENABLED' if self.betrayal.get(guild.id) else 'DISABLED'}**\nWhitelist entries: **{len(self.whitelist.get(guild.id, set()))}**"
        e.add_field(name="Protection modules", value="\n".join(f"{'ON' if values.get(k, False) else 'OFF'} · {label}" for k, label in MODULES.items()), inline=False)
        e.set_footer(text="Only the server owner can change these settings")
        return e

    @commands.command(name="autosetup")
    @commands.guild_only()
    async def autosetup(self, ctx, action: str = "run"):
        if not await self.owner_only(ctx): return
        if action.lower() == "status":
            role = ctx.guild.get_role(self.protected_ids.get(ctx.guild.id, 0))
            log_id = int(getattr(config, "LOG_CHANNEL_ID", 0) or 0)
            log_channel = ctx.guild.get_channel(log_id) if log_id else None
            e = discord.Embed(title="Durex Security | Auto Setup Status", color=discord.Color.blurple(), timestamp=discord.utils.utcnow())
            e.add_field(name="Protected role", value=role.mention if role else "Not created", inline=False)
            e.add_field(name="Log channel", value=log_channel.mention if log_channel else "Not configured / not found", inline=False)
            e.add_field(name="Manage Roles", value="Available" if ctx.guild.me and ctx.guild.me.guild_permissions.manage_roles else "Missing", inline=True)
            e.add_field(name="View Audit Log", value="Available" if ctx.guild.me and ctx.guild.me.guild_permissions.view_audit_log else "Missing", inline=True)
            return await ctx.reply(embed=e, mention_author=False)
        if action.lower() != "run":
            return await ctx.reply(embed=discord.Embed(title="Auto Setup | Usage", description="Use `7autosetup` or `7autosetup status`.", color=discord.Color.orange()), mention_author=False)
        try:
            role = await self.ensure_protected_role(ctx.guild)
        except (discord.Forbidden, discord.HTTPException, commands.CommandError) as exc:
            return await ctx.reply(embed=discord.Embed(title="Auto Setup Failed", description=str(exc), color=discord.Color.red()), mention_author=False)
        self.modules.setdefault(ctx.guild.id, {m: False for m in MODULES})
        self.save()
        me = ctx.guild.me
        log_id = int(getattr(config, "LOG_CHANNEL_ID", 0) or 0)
        log_channel = ctx.guild.get_channel(log_id) if log_id else None
        e = discord.Embed(title="Durex Security | Auto Setup Complete", description="Base configuration has been initialized. AntiNuke modules remain disabled until you enable them.", color=discord.Color.green(), timestamp=discord.utils.utcnow())
        e.add_field(name="Protected role", value=f"{role.mention} (`{role.id}`)", inline=False)
        e.add_field(name="Manage Roles", value="Ready" if me and me.guild_permissions.manage_roles else "Missing", inline=True)
        e.add_field(name="View Audit Log", value="Ready" if me and me.guild_permissions.view_audit_log else "Missing", inline=True)
        e.add_field(name="Log channel", value=log_channel.mention if log_channel else "Configure LOG_CHANNEL_ID in config.py", inline=False)
        e.add_field(name="Next step", value="Use `?antinuke enable all` to enable all protection modules, or enable categories individually.", inline=False)
        await ctx.reply(embed=e, mention_author=False)
        await self.log(ctx.guild, "Auto setup completed", f"Setup run by {ctx.author} (`{ctx.author.id}`).", discord.Color.green())

    @commands.group(name="antinuke", invoke_without_command=True)
    @commands.guild_only()
    async def antinuke(self, ctx):
        e = discord.Embed(title="Durex Security | AntiNuke", description="Use `7antinuke enable [category]`, `7antinuke disable [category]`, or `7antinuke status`.", color=discord.Color.blurple())
        e.add_field(name="Categories", value="`all`, `roles`, `channels`, `webhooks`, `antibot`, `kicks`, `bans`, `guildUpdate`", inline=False)
        await ctx.reply(embed=e, mention_author=False)

    @antinuke.command(name="enable")
    @commands.guild_only()
    async def enable(self, ctx, category: str = "all"):
        if not await self.owner_only(ctx): return
        category = category.lower()
        aliases = {"guildupdate": "guildUpdate", "guild_update": "guildUpdate", "role": "roles", "channel": "channels", "webhook": "webhooks", "bot": "antibot", "kick": "kicks", "ban": "bans", "emoji": "emojis"}
        category = aliases.get(category, category)
        if category != "all" and category not in MODULES:
            return await ctx.reply(embed=discord.Embed(title="Unknown category", description="Choose `all`, `roles`, `channels`, `webhooks`, `antibot`, `kicks`, `bans`, `guildUpdate`, `emojis`, or `prune`.", color=discord.Color.red()), mention_author=False)
        try:
            role = await self.ensure_protected_role(ctx.guild)
        except (discord.Forbidden, discord.HTTPException, commands.CommandError) as exc:
            return await ctx.reply(embed=discord.Embed(title="Setup failed", description=str(exc), color=discord.Color.red()), mention_author=False)
        values = self.modules.setdefault(ctx.guild.id, {m: False for m in MODULES})
        if category == "all":
            values.update({m: True for m in MODULES})
        else:
            values[category] = True
        self.enabled[ctx.guild.id] = any(values.values())
        self.save()
        label = "all AntiNuke categories" if category == "all" else MODULES[category]
        e = discord.Embed(title="AntiNuke Enabled", description=f"Enabled **{label}**.\nProtected role: {role.mention}", color=discord.Color.green(), timestamp=discord.utils.utcnow())
        e.add_field(name="Active modules", value="\n".join(f"{'ON' if values.get(k) else 'OFF'} · {v}" for k, v in MODULES.items()), inline=False)
        await ctx.reply(embed=e, mention_author=False)
        await self.log(ctx.guild, "AntiNuke enabled", f"Category: {label}\nChanged by: {ctx.author} (`{ctx.author.id}`).", discord.Color.green())

    @antinuke.command(name="disable")
    @commands.guild_only()
    async def disable(self, ctx, category: str = "all"):
        if not await self.owner_only(ctx): return
        category = category.lower()
        aliases = {"guildupdate": "guildUpdate", "guild_update": "guildUpdate", "role": "roles", "channel": "channels", "webhook": "webhooks", "bot": "antibot", "kick": "kicks", "ban": "bans", "emoji": "emojis"}
        category = aliases.get(category, category)
        if category != "all" and category not in MODULES:
            return await ctx.reply(embed=discord.Embed(title="Unknown category", description="Choose `all`, `roles`, `channels`, `webhooks`, `antibot`, `kicks`, `bans`, `guildUpdate`, `emojis`, or `prune`.", color=discord.Color.red()), mention_author=False)
        values = self.modules.setdefault(ctx.guild.id, {m: False for m in MODULES})
        if category == "all": values.update({m: False for m in MODULES})
        else: values[category] = False
        self.enabled[ctx.guild.id] = any(values.values())
        self.save()
        label = "all AntiNuke categories" if category == "all" else MODULES[category]
        await ctx.reply(embed=discord.Embed(title="AntiNuke Disabled", description=f"Disabled **{label}**. Anti-Betrayal remains separately configured.", color=discord.Color.orange(), timestamp=discord.utils.utcnow()), mention_author=False)
        await self.log(ctx.guild, "AntiNuke disabled", f"Category: {label}\nChanged by: {ctx.author} (`{ctx.author.id}`).", discord.Color.orange())

    @antinuke.command(name="status")
    @commands.guild_only()
    async def status(self, ctx):
        await ctx.reply(embed=self.module_embed(ctx.guild), mention_author=False)

    @antinuke.group(name="whitelist", invoke_without_command=True)
    @commands.guild_only()
    async def whitelist(self, ctx):
        users = self.whitelist.get(ctx.guild.id, set())
        desc = "\n".join(f"• <@{uid}> (`{uid}`)" for uid in sorted(users)) or "No users are whitelisted."
        e = discord.Embed(title="AntiNuke | Whitelist", description=desc, color=discord.Color.blurple())
        e.set_footer(text="Anti-Betrayal mode ignores whitelist entries")
        await ctx.reply(embed=e, mention_author=False)

    @whitelist.command(name="add")
    @commands.guild_only()
    async def whitelist_add(self, ctx, member: discord.Member):
        if not await self.owner_only(ctx): return
        self.whitelist.setdefault(ctx.guild.id, set()).add(member.id); self.save()
        await ctx.reply(embed=discord.Embed(title="Whitelist updated", description=f"Added {member.mention}. Anti-Betrayal ignores whitelist entries.", color=discord.Color.green()), mention_author=False)

    @whitelist.command(name="remove")
    @commands.guild_only()
    async def whitelist_remove(self, ctx, member: discord.Member):
        if not await self.owner_only(ctx): return
        self.whitelist.setdefault(ctx.guild.id, set()).discard(member.id); self.save()
        await ctx.reply(embed=discord.Embed(title="Whitelist updated", description=f"Removed {member.mention}.", color=discord.Color.orange()), mention_author=False)

    @commands.group(name="antibetrayal", aliases=["antibetrayla"], invoke_without_command=True)
    @commands.guild_only()
    async def antibetrayal(self, ctx):
        e = discord.Embed(title="Anti-Betrayal Mode", description="Use `7antibetrayal enable`, `disable`, or `status`.", color=discord.Color.blurple())
        await ctx.reply(embed=e, mention_author=False)

    @antibetrayal.command(name="enable")
    @commands.guild_only()
    async def betrayal_enable(self, ctx):
        if not await self.owner_only(ctx): return
        self.betrayal[ctx.guild.id] = True; self.save()
        await ctx.reply(embed=discord.Embed(title="Anti-Betrayal Enabled", description="Only the actual server owner is trusted. Whitelist, bot-owner IDs and Extra Owners do not bypass this mode.", color=discord.Color.red()), mention_author=False)
        await self.log(ctx.guild, "Anti-Betrayal enabled", "Whitelist and Extra Owner trust bypasses are disabled in this mode.", discord.Color.red())

    @antibetrayal.command(name="disable")
    @commands.guild_only()
    async def betrayal_disable(self, ctx):
        if not await self.owner_only(ctx): return
        self.betrayal[ctx.guild.id] = False; self.save()
        await ctx.reply(embed=discord.Embed(title="Anti-Betrayal Disabled", description="Normal whitelist and Extra Owner trust rules are restored. AntiNuke module settings are unchanged.", color=discord.Color.green()), mention_author=False)
        await self.log(ctx.guild, "Anti-Betrayal disabled", "Normal trust rules restored.", discord.Color.green())

    @antibetrayal.command(name="status")
    @commands.guild_only()
    async def betrayal_status(self, ctx):
        await ctx.reply(embed=discord.Embed(title="Anti-Betrayal Status", description=f"Mode: **{'ENABLED' if self.betrayal.get(ctx.guild.id) else 'DISABLED'}**", color=discord.Color.blurple()), mention_author=False)

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        g = role.guild
        if not self.active(g.id, "roles"): return
        entry = await find_audit_actor(g, discord.AuditLogAction.role_create, role.id)
        if entry and entry.user and not self.is_trusted(g, entry.user.id): await self.respond_to_actor(g, entry.user.id, f"unauthorized role creation: {role.name}")

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        g = role.guild
        if role.id == self.protected_ids.get(g.id):
            try:
                if g.me and g.me.guild_permissions.manage_roles:
                    replacement = await g.create_role(name=PROTECTED_ROLE_NAME, permissions=discord.Permissions.none(), reason="Recreate protected role")
                    self.protected_ids[g.id] = replacement.id
                    self.snapshots[g.id] = {"name": replacement.name, "permissions": replacement.permissions.value, "colour": replacement.colour.value, "hoist": replacement.hoist, "mentionable": replacement.mentionable}
                    self.save()
            except (discord.Forbidden, discord.HTTPException): pass
        if not self.active(g.id, "roles"): return
        entry = await find_audit_actor(g, discord.AuditLogAction.role_delete, role.id)
        if entry and entry.user and not self.is_trusted(g, entry.user.id): await self.respond_to_actor(g, entry.user.id, f"unauthorized role deletion: {role.name}")

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        g = after.guild
        if after.id == self.protected_ids.get(g.id):
            snap = self.snapshots.get(g.id, {})
            if snap and (before.name != after.name or before.permissions != after.permissions or before.colour != after.colour or before.hoist != after.hoist or before.mentionable != after.mentionable):
                try:
                    await after.edit(name=snap.get("name", PROTECTED_ROLE_NAME), permissions=discord.Permissions(snap.get("permissions", 0)), colour=discord.Colour(snap.get("colour", 0)), hoist=snap.get("hoist", False), mentionable=snap.get("mentionable", False), reason="Restore protected role settings")
                except (discord.Forbidden, discord.HTTPException): pass
        if not self.active(g.id, "roles"): return
        if before.permissions == after.permissions and before.name == after.name and before.colour == after.colour and before.hoist == after.hoist and before.mentionable == after.mentionable: return
        entry = await find_audit_actor(g, discord.AuditLogAction.role_update, after.id)
        if entry and entry.user and not self.is_trusted(g, entry.user.id): await self.respond_to_actor(g, entry.user.id, f"unauthorized role update: {after.name}")

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        g = channel.guild
        if not self.active(g.id, "channels"): return
        entry = await find_audit_actor(g, discord.AuditLogAction.channel_create, channel.id)
        if entry and entry.user and not self.is_trusted(g, entry.user.id): await self.respond_to_actor(g, entry.user.id, f"unauthorized channel creation: {channel.name}")

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        g = channel.guild
        if not self.active(g.id, "channels"): return
        entry = await find_audit_actor(g, discord.AuditLogAction.channel_delete, channel.id)
        if entry and entry.user and not self.is_trusted(g, entry.user.id): await self.respond_to_actor(g, entry.user.id, f"unauthorized channel deletion: {channel.name}")

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before, after):
        g = after.guild
        if not self.active(g.id, "channels"): return
        if before.name == after.name and before.overwrites == after.overwrites and getattr(before, "topic", None) == getattr(after, "topic", None): return
        entry = await find_audit_actor(g, discord.AuditLogAction.channel_update, after.id)
        if entry and entry.user and not self.is_trusted(g, entry.user.id): await self.respond_to_actor(g, entry.user.id, f"unauthorized channel update: {after.name}")

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        g = channel.guild
        if not self.active(g.id, "webhooks"): return
        for action_name in ("webhook_create", "webhook_update", "webhook_delete"):
            action = getattr(discord.AuditLogAction, action_name, None)
            if action is None: continue
            try:
                async for entry in g.audit_logs(limit=5, action=action):
                    age = (discord.utils.utcnow() - entry.created_at).total_seconds()
                    if 0 <= age <= 10 and entry.user and not self.is_trusted(g, entry.user.id):
                        await self.respond_to_actor(g, entry.user.id, f"recent webhook change in #{channel.name}")
                        return
            except (discord.Forbidden, discord.HTTPException): return

    @commands.Cog.listener()
    async def on_guild_integrations_update(self, guild):
        if not self.active(guild.id, "webhooks"): return
        for action_name in ("integration_create", "integration_update", "integration_delete"):
            action = getattr(discord.AuditLogAction, action_name, None)
            if action is None: continue
            try:
                async for entry in guild.audit_logs(limit=5, action=action):
                    age = (discord.utils.utcnow() - entry.created_at).total_seconds()
                    if 0 <= age <= 10 and entry.user and not self.is_trusted(guild, entry.user.id):
                        await self.respond_to_actor(guild, entry.user.id, f"unauthorized integration change ({action_name})")
                        return
            except (discord.Forbidden, discord.HTTPException): return

    @commands.Cog.listener()
    async def on_guild_update(self, before, after):
        if not self.active(after.id, "guildUpdate"): return
        entry = await find_audit_actor(after, discord.AuditLogAction.guild_update, after.id)
        if entry and entry.user and not self.is_trusted(after, entry.user.id):
            await self.respond_to_actor(after, entry.user.id, "unauthorized server settings update")

    @commands.Cog.listener()
    async def on_member_join(self, member):
        g = member.guild
        if not self.active(g.id, "antibot") or not member.bot: return
        await asyncio.sleep(1.2)
        entry = await find_audit_actor(g, discord.AuditLogAction.bot_add, member.id)
        if not entry or not entry.user: return
        if member.guild_permissions.administrator and not self.is_trusted(g, entry.user.id):
            await self.respond_to_actor(g, entry.user.id, f"added bot with Administrator permission: {member} (`{member.id}`)")
            try:
                await member.kick(reason="Durex Security: untrusted actor added an Administrator bot")
                result = "Added bot kicked."
            except (discord.Forbidden, discord.HTTPException): result = "Could not kick added bot due to permissions or hierarchy."
            await self.log(g, "Administrator bot add detected", f"Bot: {member} (`{member.id}`)\nInviter: {entry.user} (`{entry.user.id}`)\n{result}", discord.Color.red())

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        if not self.active(guild.id, "bans"): return
        entry = await find_audit_actor(guild, discord.AuditLogAction.ban, user.id)
        if not entry or not entry.user: return
        actor_id = entry.user.id
        now = time.monotonic(); window = float(getattr(config, "MASS_BAN_WINDOW_SECONDS", 15))
        q = self.ban_events[(guild.id, actor_id)]; q.append(now)
        while q and now - q[0] > window: q.popleft()
        threshold = int(getattr(config, "MASS_BAN_THRESHOLD", 10))
        if len(q) > threshold and not self.is_trusted(guild, actor_id):
            await self.respond_to_actor(guild, actor_id, f"mass-ban threshold exceeded: {len(q)} bans in {window:.0f}s")
            q.clear()

    @commands.Cog.listener()
    async def on_guild_emojis_update(self, guild, before, after):
        if not self.active(guild.id, "emojis"): return
        before_ids = {emoji.id for emoji in before}
        after_ids = {emoji.id for emoji in after}
        deleted_ids = before_ids - after_ids
        for emoji_id in deleted_ids:
            entry = await find_audit_actor(guild, discord.AuditLogAction.emoji_delete, emoji_id)
            if entry and entry.user and not self.is_trusted(guild, entry.user.id):
                await self.respond_to_actor(guild, entry.user.id, f"unauthorized emoji deletion (emoji ID {emoji_id})")
                return

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        g = member.guild
        if self.active(g.id, "prune"):
            prune_action = getattr(discord.AuditLogAction, "member_prune", None)
            if prune_action is not None:
                entry = await find_audit_actor(g, prune_action, g.id)
                if entry and entry.user and not self.is_trusted(g, entry.user.id):
                    handled = getattr(self, "handled_prunes", set())
                    if entry.id not in handled:
                        handled.add(entry.id)
                        self.handled_prunes = handled
                        await self.respond_to_actor(g, entry.user.id, "unauthorized member prune detected")
        if not self.active(g.id, "kicks"): return
        entry = await find_audit_actor(g, discord.AuditLogAction.kick, member.id)
        if not entry or not entry.user: return
        actor_id = entry.user.id
        now = time.monotonic(); window = float(getattr(config, "MASS_BAN_WINDOW_SECONDS", 15))
        q = self.kick_events[(g.id, actor_id)]; q.append(now)
        while q and now - q[0] > window: q.popleft()
        if not self.is_trusted(g, actor_id):
            if len(q) > int(getattr(config, "MASS_BAN_THRESHOLD", 10)):
                await self.respond_to_actor(g, actor_id, f"mass-kick threshold exceeded: {len(q)} kicks in {window:.0f}s")
                q.clear()
            else:
                await self.respond_to_actor(g, actor_id, f"unauthorized kick of member {member} (`{member.id}`)")

async def setup(bot):
    await bot.add_cog(Security(bot))
