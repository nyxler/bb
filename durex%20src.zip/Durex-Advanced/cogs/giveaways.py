import asyncio, random, time
import discord
from discord.ext import commands

class Giveaways(commands.Cog):
    def __init__(self, bot): self.bot=bot; self.active={}
    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def giveaway(self, ctx, seconds: int, winners: int, *, prize: str):
        if not 10 <= seconds <= 604800: return await ctx.reply("Duration must be 10 seconds to 7 days.", mention_author=False)
        if not 1 <= winners <= 20: return await ctx.reply("Winner count must be 1–20.", mention_author=False)
        end=int(time.time()+seconds)
        e=discord.Embed(title=f"Giveaway: {prize}", description=f"React with 🎉 to enter.\nWinners: **{winners}**\nEnds: <t:{end}:R>", color=discord.Color.blurple())
        e.set_footer(text=f"Host: {ctx.author} | Durex Security")
        msg=await ctx.send(embed=e); await msg.add_reaction("🎉")
        self.active[msg.id]=True
        await asyncio.sleep(seconds)
        try: msg=await ctx.channel.fetch_message(msg.id)
        except (discord.NotFound,discord.Forbidden,discord.HTTPException): self.active.pop(msg.id,None); return
        entrants=[]
        for reaction in msg.reactions:
            if str(reaction.emoji)=="🎉":
                async for user in reaction.users():
                    if not user.bot: entrants.append(user)
        entrants=list({u.id:u for u in entrants}.values()); random.shuffle(entrants)
        chosen=entrants[:winners]; self.active.pop(msg.id,None)
        if chosen: await ctx.send(f"Giveaway ended! Winner(s): {', '.join(u.mention for u in chosen)} — Prize: **{prize}**")
        else: await ctx.send(f"Giveaway ended for **{prize}**, but nobody entered.")

    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def reroll(self, ctx, message_id: int):
        try: msg=await ctx.channel.fetch_message(message_id)
        except (discord.NotFound,discord.Forbidden,discord.HTTPException): return await ctx.reply("Could not find that message in this channel.", mention_author=False)
        entrants=[]
        for reaction in msg.reactions:
            if str(reaction.emoji)=="🎉":
                async for user in reaction.users():
                    if not user.bot: entrants.append(user)
        entrants=list({u.id:u for u in entrants}.values())
        if not entrants: return await ctx.reply("No eligible entrants found.", mention_author=False)
        await ctx.send(f"Rerolled winner: {random.choice(entrants).mention}")

async def setup(bot): await bot.add_cog(Giveaways(bot))
