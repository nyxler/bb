import re, time
from collections import defaultdict, deque
import discord
from discord.ext import commands
import config

INVITE_RE = re.compile(r"(?:discord\.gg/|discord(?:app)?\.com/invite/)[\w-]+", re.I)
URL_RE = re.compile(r"https?://\S+", re.I)

class AutoMod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.recent = defaultdict(deque)
        self.mention_counts = defaultdict(deque)

    @commands.Cog.listener()
    async def on_message(self, message):
        if not message.guild or message.author.bot: return
        member = message.author
        if not isinstance(member, discord.Member): return
        if member.guild_permissions.manage_messages: return
        now = time.monotonic(); key = (message.guild.id, member.id)
        window = float(getattr(config, "ANTI_SPAM_SECONDS", 7)); threshold = int(getattr(config, "ANTI_SPAM_MESSAGES", 7))
        q = self.recent[key]; q.append(now)
        while q and now - q[0] > window: q.popleft()
        reason = None
        if len(q) >= threshold:
            reason = "spam rate exceeded"
            q.clear()
        elif len(message.mentions) >= 6:
            reason = "mass mention"
        elif INVITE_RE.search(message.content):
            reason = "Discord invite link"
        if reason:
            try:
                await message.delete()
                await message.channel.send(f"{member.mention}, message blocked: {reason}.", delete_after=5)
            except (discord.Forbidden, discord.HTTPException): pass

async def setup(bot): await bot.add_cog(AutoMod(bot))
