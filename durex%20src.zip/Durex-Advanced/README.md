# DUREX SECURITY

**Developed by Nyxler </>**

A modular Python Discord bot with a blue-themed embed style, moderation, security toggles, automod, roles, welcome messages, utilities, games, giveaways, and logging. Global prefix: `7`. Per-server prefix can be set by the server owner.

## Quick start — Windows
1. Install Python 3.11 or newer.
2. Open this folder and edit `config.py`.
3. Put your bot token in `TOKEN`, your Discord user ID in `OWNER_IDS`, and configure channel IDs if needed.
4. Run `run_windows.bat` or use `py main.py` in a terminal.

## Quick start — Linux / VPS / Cloud Shell
1. Install Python 3.11 or newer.
2. Edit `config.py` with your bot token and IDs.
3. Run `python3 -m pip install -r requirements.txt`.
4. Run `python3 main.py` (or `./run_linux.sh`).

## Discord Developer Portal
Enable **Server Members Intent** and **Message Content Intent**. Invite the bot with the permissions it needs and place its top role above roles it must manage. Avoid granting Administrator unless necessary.

## Commands
- `7customprefix !` / `/customprefix` — server owner only. Global `7` remains as fallback.
- `7extraowner add @member`, `7extraowner remove @member`, `7extraowner list` — server owner only, maximum five slots. `/extraowners` lists slots.
- `/customprefix` and other application commands are synced on startup.
- `7autosetup` / `7autosetup status`
- `7antinuke enable all`, `7antinuke disable all`, `7antinuke status`
- `7antinuke enable roles|channels|webhooks|antibot|kicks|bans|guildUpdate`
- `7antinuke whitelist add @member` / `7antinuke whitelist remove @member`
- `7antibetrayal enable|disable|status`
- `7helpme`, `7ping`, `7userinfo`, `7serverinfo`, `7avatar`, `7poll`
- Moderation commands include kick, ban, unban, timeout, purge, slowmode, lock and unlock.
- Other modules include automod, role management, welcome, fun, giveaways and event logging.

## Important feature limits
This is a modular starter, not a claim of full feature parity with another bot. Music/Lavalink, a web dashboard, backup/restore, ticketing, advanced automod rules and settings and security state are persisted in SQLite (`data/durex.sqlite3`). Per-server custom prefix and up to five ExtraOwner slots are included. Some advanced modules are not full feature-parity with other bots. Security toggles only enforce behavior implemented in the corresponding listeners; test in a private server before using in a production community. Discord audit logs can be delayed, and Discord role hierarchy limits what the bot can manage.

## Secret handling
Never publish `config.py` or your bot token. If a token or OAuth secret has been pasted into a chat or public repository, reset it in the Discord Developer Portal before running the bot. `config.py` is excluded by `.gitignore`.
