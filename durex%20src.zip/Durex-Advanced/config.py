"""Durex Security configuration. Add your bot token here; never publish this file."""
TOKEN = "PASTE_DISCORD_BOT_TOKEN_HERE"
PREFIX = "7"

# IDs must be integers. Keep EXTRA_OWNERS to at most five IDs.
OWNER_IDS = [123456789012345678]
EXTRA_OWNERS = [
    # 111111111111111111,
    # 222222222222222222,
    # 333333333333333333,
    # 444444444444444444,
    # 555555555555555555,
]

LOG_CHANNEL_ID = 0       # Replace 0 with your security-log channel ID
JOIN_LEAVE_LOG_CHANNEL_ID = 0  # Optional separate join/leave log channel
WELCOME_CHANNEL_ID = 0   # Replace 0 with your welcome channel ID
ANTI_SPAM_MESSAGES = 7
ANTI_SPAM_SECONDS = 7
MASS_BAN_THRESHOLD = 10   # Anti-betrayal triggers when MORE than 10 bans happen in the window
MASS_BAN_WINDOW_SECONDS = 15
